﻿using Assignment_3.Qustion_01;
using Assignment_3.Qustion_02;
using Assignment_3.Qustion_03;

namespace Assignment_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Part 1
            //1-b
            //2-a
            //3-b
            //4-b
            //5-d
            //6-a
            //7-b
            //8-a
            //9-b
            //10-c
            #endregion
            #region Part 2
            #region Qustion 01
            //Circle c1 = new Circle(2);
            //c1.DisplayShapeInfo();
            //Rectangle r1 = new Rectangle(3, 4);
            //r1.DisplayShapeInfo(); 
            #endregion

            #region Qustion 02
            //IAuthenticationService[] service = {new BasicAuthenticationService("Higzo","higzo2005","Admin"),
            //                                        new BasicAuthenticationService("Khafagy","higzo2005","User"),
            //                                        new BasicAuthenticationService("Adham","higzo2005","User")};


            //Console.Write("UserName: "); string? un = Console.ReadLine();
            //Console.Write("Password: "); string? pw = Console.ReadLine();
            //Console.Write("Role: "); string? r = Console.ReadLine();
            //var foundUser = service.FirstOrDefault(s => s.AuthenticateUser(un, pw) && s.AuthorizeUser(un, r));
            //if (foundUser != null)
            //{
            //    Console.WriteLine(" Access Granted");
            //}
            //else
            //{
            //    Console.WriteLine(" Access Denied");
            //} 
            #endregion

            #region Qustion 03
            //INotificationService[] service = { new EmailNotificationService(), 
            //                                   new PushNotificationService(),
            //                                   new SmsNotificationService()};

            INotificationService service01 = new EmailNotificationService();
            INotificationService service02 = new PushNotificationService();
            INotificationService service03 = new SmsNotificationService();

            service01.SendNotification(1,"Welcome in email");
            Console.WriteLine("-------------------------------");
            service03.SendNotification(2, "Welcome in sms");
            Console.WriteLine("-------------------------------");
            service02.SendNotification(3, "Welcome in push");
            #endregion
            #endregion

        }
    }
}
