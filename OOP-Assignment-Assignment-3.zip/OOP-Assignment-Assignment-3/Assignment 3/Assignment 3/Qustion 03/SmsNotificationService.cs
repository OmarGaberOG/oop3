﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3.Qustion_03
{
    internal class SmsNotificationService : INotificationService
    {
        public void SendNotification(int recipient, string message)
        {
            Console.WriteLine($"SmsNotificationService:\n\nRecipient: {recipient}\nMassage: {message}");
        }
    }
}
