﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Assignment_3.Qustion_02
{
    public class BasicAuthenticationService : IAuthenticationService
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
        public BasicAuthenticationService(string username, string password, string role)
        {
            Username = username;
            Password = password;
            Role = role;
        }
        public bool AuthorizeUser(string? username, string? role)
        {
            if (username == Username && role == Role)
            {
                return true;
            }
            return false;
        }
        public bool AuthenticateUser(string? username, string? password)
        {
            if (username == Username && password == Password)
            {
                return true;
            }
            return false;
        }
    }
}
