﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3.Qustion_02
{
    internal interface IAuthenticationService
    {
        bool AuthorizeUser(string? username,string? role);
        bool AuthenticateUser(string? username,string? password);
    }
}
