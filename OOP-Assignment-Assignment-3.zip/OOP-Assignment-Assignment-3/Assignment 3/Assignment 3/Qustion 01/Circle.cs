﻿using Assignment_3.NewFolder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3.Qustion_01
{
    internal class Circle : ICircle
    {
        public double Area { get ; set; }
        public double radius { get ; set ; }
        public Circle(double radius)
        {
            radius = radius;
            Area = 3.14 * radius * radius;
        }
        public void DisplayShapeInfo()
        {
            Console.WriteLine($"Circle Area: {Area}");
        }
    }
}
