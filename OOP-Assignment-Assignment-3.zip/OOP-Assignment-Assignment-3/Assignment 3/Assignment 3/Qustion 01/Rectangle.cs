﻿using Assignment_3.NewFolder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3.Qustion_01
{
    internal class Rectangle :IRectangle
    {
        public double Area { get; set ; }
        public double Width { get ; set ; }
        public double Height { get ; set ; }
        public Rectangle(double width, double height)
        {
            Width = width;
            Height = height;
            Area = Width * Height;
        }

        public void DisplayShapeInfo()
        {
            Console.WriteLine($"Rectangle Area: {Area}");
        }
    }
}
